# Last-Project-Pemweb-Kel-2
Smart Inventory: Aplikasi Pengelolaan Barang Masuk-Keluar  Dan Kalkulasi Keuntungan
