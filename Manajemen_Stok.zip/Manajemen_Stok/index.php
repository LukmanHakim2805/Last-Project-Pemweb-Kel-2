<?php
include 'db.php';
$result = $conn->query("SELECT produk.*, kategori.nama_kategori FROM produk LEFT JOIN kategori ON produk.id_kategori = kategori.id");
?>

<h2>Daftar Produk - TOKO DASHA</h2>
<a href="restock_log.php">Lihat Riwayat Restock</a>
<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>Nama Produk</th>
        <th>Kategori</th>
        <th>Harga</th>
        <th>Stok</th>
        <th>Aksi</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['nama_produk'] ?></td>
        <td><?= $row['nama_kategori'] ?></td>
        <td><?= number_format($row['harga'], 2) ?></td>
        <td><?= $row['stok'] ?></td>
        <td><a href="restock.php?id=<?= $row['id'] ?>">Restock</a></td>
    </tr>
    <?php endwhile; ?>
</table>