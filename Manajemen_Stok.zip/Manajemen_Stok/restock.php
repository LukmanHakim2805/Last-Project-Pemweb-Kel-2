<?php
include 'db.php';
$query = "
    SELECT r.*, p.nama_produk, a.username 
    FROM restock r
    LEFT JOIN produk p ON r.id_produk = p.id
    LEFT JOIN admin a ON r.id_admin = a.id
    ORDER BY r.tanggal DESC
";
$result = $conn->query($query);
?>

<h2>Riwayat Restock</h2>
<a href="index.php">Kembali ke daftar</a>
<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>Tanggal</th>
        <th>Produk</th>
        <th>Jumlah</th>
        <th>Keterangan</th>
        <th>Admin</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['tanggal'] ?></td>
        <td><?= $row['nama_produk'] ?></td>
        <td><?= $row['jumlah'] ?></td>
        <td><?= $row['keterangan'] ?></td>
        <td><?= $row['username'] ?></td>
    </tr>
    <?php endwhile; ?>
</table>
