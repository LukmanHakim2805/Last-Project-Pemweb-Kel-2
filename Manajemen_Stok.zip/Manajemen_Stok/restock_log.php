<?php
include 'db.php';

$id_produk = $_POST['id_produk'];
$jumlah = $_POST['jumlah'];
$keterangan = $_POST['keterangan'];
$id_admin = $_POST['id_admin'];
$tanggal = date('Y-m-d');

// Simpan ke tabel restock
$conn->query("INSERT INTO restock (id_produk, jumlah, tanggal, keterangan, id_admin)
              VALUES ($id_produk, $jumlah, '$tanggal', '$keterangan', $id_admin)");

// Update stok produk
$conn->query("UPDATE produk SET stok = stok + $jumlah WHERE id = $id_produk");

header("Location: index.php");