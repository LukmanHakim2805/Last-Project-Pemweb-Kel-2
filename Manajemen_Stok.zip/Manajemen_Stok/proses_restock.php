<?php
include 'db.php';
$id = $_GET['id'];
$data = $conn->query("SELECT * FROM produk WHERE id = $id")->fetch_assoc();
?>

<h2>Restock Produk: <?= $data['nama_produk'] ?></h2>

<form action="proses_restock.php" method="post">
    <input type="hidden" name="id_produk" value="<?= $data['id'] ?>">
    Jumlah Tambah: <input type="number" name="jumlah" required><br><br>
    Keterangan (opsional): <input type="text" name="keterangan"><br><br>
    ID Admin: <input type="number" name="id_admin" required><br><br>
    <input type="submit" value="Restock">
</form>
<a href="index.php">Kembali ke daftar</a>